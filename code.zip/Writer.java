
package icp_java_week4;
import java.io.*;
import java.util.Scanner;

public class Writer {
    public Writer(){ }

    public void writingTextToFile() throws IOException {
        PrintWriter printWriter = null;



        try {
            printWriter = new PrintWriter(new FileOutputStream("essentials_stock.txt", true));
        }catch(FileNotFoundException fnfe) {
            fnfe.getMessage();
        }





        Items item1 = new Items("oil", 3, 5);
        Items item2 = new Items("book", 6, 34);
        Items item3 = new Items("snapple", 9, 56);
        Items item4 = new Items("milo", 23,78 );
        Items item5 = new Items("oil", 7, 6);
        Items item6 = new Items("indomie", 6, 7);
        Items item7 = new Items("delight", 5, 8);
        Items item8 = new Items("kalyppo", 4, 9);
        Items item9= new Items("pen", 3, 10);
        Items item10= new Items("nido", 2, 11);

        //write ten items to the file
        printWriter.print(item1.printMethod());
        printWriter.print(item2.printMethod());
        printWriter.print(item3.printMethod());
        printWriter.print(item4.printMethod());
        printWriter.print(item5.printMethod());
        printWriter.print(item6.printMethod());
        printWriter.print(item7.printMethod());
        printWriter.print(item8.printMethod());
        printWriter.print(item9.printMethod());
        printWriter.print(item10.printMethod());




        /* prompt the user to enter more items
        and write them to the file(essentials_stock.txt)

         */

        System.out.println("HOW MANY ITEMS DO YOU WANT TO ADD?");
        Scanner n1 = new Scanner(System.in);
        int n=n1.nextInt();


        if(n<0  || n>Integer.MAX_VALUE||n<Integer.MIN_VALUE){
            try{
                throw new Exception("Illegal argument");
            }catch(Exception e){
                System.out.println(e.getMessage());
                System.exit(0);
            }
        }




        try{
        for (int i=0; i<n;i++) {
            System.out.println("enter the product name");
            Scanner prod = new Scanner(System.in);
            String product = prod.nextLine();

            System.out.println("enter the price");
            Scanner p = new Scanner(System.in);
            int price = prod.nextInt();

            System.out.println("enter quantity");
            Scanner q = new Scanner(System.in);
            int quant = prod.nextInt();

            Items item11 = new Items(product, price, quant);
            printWriter.print(item11.printMethod());
        }
        }catch (IndexOutOfBoundsException e){
            System.out.println("Index out of bound");
        }


        printWriter.close();

        PrintWriter printWriter2 = null;
        try {
            printWriter2 = new PrintWriter(new FileOutputStream("backup_essentials_stock.txt", true));
            printWriter2.print("water");
        }catch(FileNotFoundException fnfe) {
            fnfe.getMessage();
        }




    }




    private static void backup() throws IOException {
        InputStream source = null;
        OutputStream backup = null;
        try {
            source = new FileInputStream("essentials_stock.txt");
            backup = new FileOutputStream("backup_essentials_stock.txt");

            byte[] StrTobytes = new byte[1024];

            int i;
            while ((i = source.read(StrTobytes)) > 0) {
                backup.write(StrTobytes, 0, i);
            }
        } finally {
            source.close();
            backup.close();
        }
    }





    /*
    display items on the screen
     */
    public void DisplayOnScreen() throws IOException {
            BufferedReader buff = new BufferedReader(new FileReader("essentials_stock.txt"));
            String i;
            while ((i = buff.readLine()) != null) {
                System.out.println(i);
            }
        }




    public static void main(String[] args) {
        Writer pwd = new Writer();

        try {
            pwd.writingTextToFile();
            System.out.println("**HERE ARE ITEMS CURRENTLY ON THE SHELVES OF ESSENTIALS SHOP**");
            pwd.DisplayOnScreen();
            pwd.backup();



        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}