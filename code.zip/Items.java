
package icp_java_week4;
public class Items {
    String ItemName;
    int price;
    int quantity;

    public Items(String name,int price,int quantity ){
        this.ItemName=name;
        this.price=price;
        this.quantity=quantity;
    }

    /*
    getter methods
     */
    public String getItemName(){ return ItemName; }
    public int getPrice(){ return price; }
    public int getquantity(){ return quantity; }

    /*
    setter methods
     */

    public void setProdName(String name){ ItemName=name;}
    public void setPrice(int newPrice){ price=newPrice;}
    public void setQuantity(int newquantity){ quantity=newquantity;}


    public void increaseQuantity(int increase){
        quantity+=increase;
    }


    public String printMethod(){
        return ItemName + "\t" + price + "\tGHC"  + quantity + "\n";
    }

}
